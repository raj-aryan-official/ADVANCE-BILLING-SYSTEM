/*
  # Initial Schema for Retail Billing System

  1. New Tables
    - `products`
      - Product information including name, price, stock, and QR code
    - `sales`
      - Sales transactions with date, total amount
    - `sale_items`
      - Individual items in each sale
    - `daily_reports`
      - Daily sales summaries
    - `monthly_reports`
      - Monthly sales analytics

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Products Table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  price decimal(10,2) NOT NULL,
  stock_quantity integer NOT NULL DEFAULT 0,
  qr_code text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Sales Table
CREATE TABLE IF NOT EXISTS sales (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  total_amount decimal(10,2) NOT NULL,
  tax_amount decimal(10,2) NOT NULL,
  discount_amount decimal(10,2) DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Sale Items Table
CREATE TABLE IF NOT EXISTS sale_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sale_id uuid REFERENCES sales(id),
  product_id uuid REFERENCES products(id),
  quantity integer NOT NULL,
  unit_price decimal(10,2) NOT NULL,
  total_price decimal(10,2) NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Daily Reports Table
CREATE TABLE IF NOT EXISTS daily_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL UNIQUE,
  total_sales decimal(10,2) NOT NULL DEFAULT 0,
  total_transactions integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Monthly Reports Table
CREATE TABLE IF NOT EXISTS monthly_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  year integer NOT NULL,
  month integer NOT NULL,
  total_sales decimal(10,2) NOT NULL DEFAULT 0,
  total_transactions integer NOT NULL DEFAULT 0,
  best_selling_product uuid REFERENCES products(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(year, month)
);

-- Enable Row Level Security
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE sale_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE monthly_reports ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow all operations for authenticated users" ON products
  FOR ALL TO authenticated
  USING (true);

CREATE POLICY "Allow all operations for authenticated users" ON sales
  FOR ALL TO authenticated
  USING (true);

CREATE POLICY "Allow all operations for authenticated users" ON sale_items
  FOR ALL TO authenticated
  USING (true);

CREATE POLICY "Allow all operations for authenticated users" ON daily_reports
  FOR ALL TO authenticated
  USING (true);

CREATE POLICY "Allow all operations for authenticated users" ON monthly_reports
  FOR ALL TO authenticated
  USING (true);

-- Functions for automatic updates
CREATE OR REPLACE FUNCTION update_stock_on_sale() RETURNS TRIGGER AS $$
BEGIN
  UPDATE products
  SET stock_quantity = stock_quantity - NEW.quantity
  WHERE id = NEW.product_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_stock_after_sale
  AFTER INSERT ON sale_items
  FOR EACH ROW
  EXECUTE FUNCTION update_stock_on_sale();

-- Function to update daily reports
CREATE OR REPLACE FUNCTION update_daily_report() RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO daily_reports (date, total_sales, total_transactions)
  VALUES (
    DATE(NEW.created_at),
    NEW.total_amount,
    1
  )
  ON CONFLICT (date)
  DO UPDATE SET
    total_sales = daily_reports.total_sales + NEW.total_amount,
    total_transactions = daily_reports.total_transactions + 1,
    updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_daily_report_after_sale
  AFTER INSERT ON sales
  FOR EACH ROW
  EXECUTE FUNCTION update_daily_report();